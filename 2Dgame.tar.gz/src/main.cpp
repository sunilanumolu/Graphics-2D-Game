#include "main.h"
#include "timer.h"
#include "ball.h"
#include "Board.h"
#include "boomerang.h"
#include "diamond.h"
#include "ring.h"
#include "magnet.h"

using namespace std;

GLMatrices Matrices;
GLuint programID;
GLFWwindow *window;

/**************************
* Customizable functions *
**************************/

Board Platform;
Ball Player;
vector<Ball> Coins;
vector<Ball> BeamEnds;
vector<Board> Beams;
Boomerang Booms;
vector<Ball> WaterBallons;
Diamond Power;
vector<Ring> rings;
vector<Magnet> magnets;


int score,health = 100;
char title[1000];

float screen_zoom = 1, screen_center_x = 0, screen_center_y = 0;
float camera_rotation_angle = 0;

Timer t60(1.0 / 60);

/* Render the scene with openGL */
/* Edit this function according to your assignment */
void draw()
{
    // clear the color and depth in the frame buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // use the loaded shader program
    // Don't change unless you know what you are doing
    glUseProgram(programID);

    // Eye - Location of camera. Don't change unless you are sure!!
    glm::vec3 eye(5 * cos(camera_rotation_angle * M_PI / 180.0f), 0, 5 * sin(camera_rotation_angle * M_PI / 180.0f));
    // Target - Where is the camera looking at.  Don't change unless you are sure!!
    glm::vec3 target(0, 0, 0);
    // Up - Up vector defines tilt of camera.  Don't change unless you are sure!!
    glm::vec3 up(0, 1, 0);

    // Compute Camera matrix (view)
    // Matrices.view = glm::lookAt(eye, target, up); // Rotating Camera for 3D
    // Don't change unless you are sure!!
    Matrices.view = glm::lookAt(glm::vec3(0, 0, 3), glm::vec3(0, 0, 0), glm::vec3(0, 1, 0)); // Fixed camera for 2D (ortho) in XY plane

    // Compute ViewProject matrix as view/camera might not be changed for this frame (basic scenario)
    // Don't change unless you are sure!!
    glm::mat4 VP = Matrices.projection * Matrices.view;

    // Send our transformation to the currently bound shader, in the "MVP" uniform
    // For each model you render, since the MVP will be different (at least the M part)
    // Don't change unless you are sure!!
    glm::mat4 MVP; // MVP = Projection * View * Model

    // Scene render
    Platform.draw(VP);
    Player.draw(VP);
    for(int i=0; i<Coins.size(); i++){
        Coins[i].draw(VP);        
    }
    for(int i=0; i<BeamEnds.size(); i++){
        BeamEnds[i].draw(VP);
    }
    for(int i=0; i<Beams.size(); i++){
        Beams[i].draw(VP);
    }
    Booms.draw(VP);

    for(int i=0; i<WaterBallons.size(); i++){
        WaterBallons[i].draw(VP);
    }

    if(Power.visible == 1) Power.draw(VP);

    for(int i=0; i<rings.size(); i++){
        rings[i].draw(VP);        
    }

    for(int i=0; i<magnets.size(); i++){
        magnets[i].draw(VP);        
    }

}

void tick_input(GLFWwindow *window)
{
    int left = glfwGetKey(window, GLFW_KEY_LEFT);
    int right = glfwGetKey(window, GLFW_KEY_RIGHT);
    int up = glfwGetKey(window, GLFW_KEY_UP);
    if (left)
    {
        Player.position.x -= 0.05;
        screen_center_x -= 0.045;
        reset_screen();
    }
    else if(right){
        Player.position.x += 0.05;
        screen_center_x += 0.045;
        reset_screen();
    }
    else if(up)
    {
        Player.position.y += 0.05f;
    }
}

void tick_elements()
{ 
    for(int k=0; k<Coins.size(); k++){
        Coins[k].rotation += 3;
    }
    Power.rotation += 2;

    bounding_box_t a,b,c,d,e,f;
    a.x = Player.position.x;
    a.y = Player.position.y;
    a.width = Player.radius;
    a.height = Player.radius;

    vector<Ball>::iterator coin;
    for(coin = Coins.begin(); coin != Coins.end(); coin++){
        b.x = coin->position.x;
        b.y = coin->position.y;
        b.width = coin->radius;
        b.height = coin->radius;

         if(check_collision(a, b)){
             score += 5;
             sprintf(title, "JetPackJoyride::Score : %d     Health : %d", score, health);
             Coins.erase(coin);
             break;
         }
    }

    vector<Ball>::iterator endballs;
    for(endballs = BeamEnds.begin(); endballs != BeamEnds.end(); endballs++){
        b.x = endballs->position.x;
        b.y = endballs->position.y;
        b.width = endballs->radius;
        b.height = endballs->radius;

         if(check_collision(a, b)){
            BeamEnds.erase(endballs);
            health -= 50;
            sprintf(title, "JetPackJoyride::Score : %d     Health : %d", score, health);
            if(health <= 0){
                exit(1);
            }
            break;
         }
    }


    vector<Board>::iterator beams;
    for(beams = Beams.begin(); beams != Beams.end(); beams++)
    {
        c.x = beams->position.x;
        c.y = beams->position.y;
        c.width = beams->width;
        c.height = beams->height;

        if(c.width >= c.height){
            if(check2_collision(a, c)){
                Beams.erase(beams);
                health -= 50;
                sprintf(title, "JetPackJoyride::Score : %d     Health : %d", score, health);
                if(health <= 0){
                    exit(1);
                }
                break;
               //exit(1); 
            }
        }else{
            if(check3_collision(a, c)){
                Beams.erase(beams);
                health -= 50;
                sprintf(title, "JetPackJoyride::Score : %d     Health : %d", score, health);
                if(health <= 0){
                    exit(1);
                }
                break;
                //exit(1);
        }
        }

    }

    d.x = Booms.position.x;
    d.y = Booms.position.y;
    d.width = Booms.width;
    d.height = Booms.height;

    if(check4_collision(a, d)){
        exit(1);
    }

    if((Booms.position.x - Player.position.x) < 4){
        if(Booms.position.x > 22 && Booms.position.y + 2 > Booms.width ){
            Booms.position.x -= 0.05;
        }
        else if((Booms.position.y + 2) > Booms.width){
            Booms.position.y -= 0.04;
        }
    } 

    if((Booms.position.y + 2) <= Booms.width){
        Booms.position.x += 0.05;
    }


    vector<Ball>::iterator balloons;
    for(balloons = WaterBallons.begin(); balloons != WaterBallons.end(); balloons++){
        if(balloons->position.x + balloons->radius > screen_center_x + 4 / screen_zoom){
            WaterBallons.erase(balloons);
            break;
        }
        else{
            balloons->position.x += 0.06f;
        }
    }

    vector<Ball>::iterator ballon;
    vector<Board>::iterator beam;
    for(beam = Beams.begin(); beam != Beams.end(); beam++){
        e.x = beam->position.x;
        e.y = beam->position.y;
        e.width = beam->width;
        e.height = beam->height;

        for(ballon = WaterBallons.begin(); ballon != WaterBallons.end(); ballon++){
            f.x = ballon->position.x;
            f.y = ballon->position.y;
            f.width = ballon->radius;
            f.height = ballon->radius;

            if(e.width >= e.height){
                if(check2_collision(f, e)){
                Beams.erase(beam);
                WaterBallons.erase(ballon);
                break;
                   //exit(1); 
                }
            }else{
                if(check3_collision(f, e)){
                Beams.erase(beam);
                WaterBallons.erase(ballon);
                break;
                    //exit(1);
            }
            }
        }
    }

    if(Player.position.x > Power.position.x - 0.5 && Player.position.x < Power.position.x + 0.5){
        if(Player.position.y > Power.position.y - 0.5 && Player.position.y < Power.position.y + 0.5){
            if(Power.visible == 1){
                Power.visible = 0;
                health += 50;
                sprintf(title, "JetPackJoyride::Score : %d     Health : %d", score, health);
            }
        }
    }

    if(Player.position.y > -1.7)
    {
        Player.position.y -= 0.02f;
    }

    if(Player.position.x + 7 >= 50 && Player.position.x < 50)
    {
        Player.position.x += 0.025f;
        screen_center_x += 0.02f;
    }

    camera_rotation_angle += 1;

    glfwSetWindowTitle(window, title);
}

/* Initialize the OpenGL rendering properties */
/* Add all the models to be created here */
void initGL(GLFWwindow *window, int width, int height)
{
    /* Objects should be created before any other gl function and shaders */
    // Create the models
    Platform = Board(0, -3, 1, 200, COLOR_GREEN);
    Player = Ball(-3, -1.7, 0.3, COLOR_BLACK);
    float a = -1,b = 0;
    for(int i=0; i<5; i++){
            Coins.push_back(Ball(a + i, b, 0.2, COLOR_YELLOW));
    }

    BeamEnds.push_back(Ball(4.5, -1, 0.2, COLOR_BROWN));
    BeamEnds.push_back(Ball(4.5, 3, 0.2, COLOR_BROWN));

    Beams.push_back(Board(4.5, 1, 2, 0.2, COLOR_RED));

    a = 6; b = 2;
    for(int i=0; i<4; i++){
        if(i%2 == 0)
            Coins.push_back(Ball(a + i, b + 0.5, 0.2, COLOR_YELLOW));
        else
            Coins.push_back(Ball(a + i, b - 0.5, 0.2, COLOR_YELLOW));

    }

    BeamEnds.push_back(Ball(7, 0, 0.2, COLOR_BROWN));
    BeamEnds.push_back(Ball(11, 0, 0.2, COLOR_BROWN));

    Beams.push_back(Board(9, 0, 0.2, 2, COLOR_RED));

    a = 15; b = 1.5;
    for(int i=0; i<5; i++){
        if(i%2 == 0)
            Coins.push_back(Ball(a + i, b + 1, 0.2, COLOR_YELLOW));
        else
            Coins.push_back(Ball(a + i, b - 1, 0.2, COLOR_YELLOW));

    }
    BeamEnds.push_back(Ball(13, 1.5, 0.2, COLOR_BROWN));
    BeamEnds.push_back(Ball(17, 1.5, 0.2, COLOR_BROWN));

    Beams.push_back(Board(15, 1.5, 0.2, 2, COLOR_RED));

    BeamEnds.push_back(Ball(17, 0, 0.2, COLOR_BROWN));
    BeamEnds.push_back(Ball(21, 0, 0.2, COLOR_BROWN));

    Beams.push_back(Board(19, 0, 0.2, 2, COLOR_RED));

    Booms = Boomerang(25, 2, 0.1, 0.4, COLOR_PURPLE);

    BeamEnds.push_back(Ball(23, 0, 0.2, COLOR_BROWN));
    BeamEnds.push_back(Ball(27, 0, 0.2, COLOR_BROWN));

    Beams.push_back(Board(25, 0, 0.2, 2, COLOR_RED));

    Power = Diamond(29, 0, COLOR_CRIMSON);

    a = 31; b = 0.5;
    for(int i=0; i<4; i++){
            Coins.push_back(Ball(a + i, b, 0.2, COLOR_YELLOW));
    }

    rings.push_back(Ring(37, 1, 2, COLOR_GREY));
    rings.push_back(Ring(37, 1, 1, COLOR_BACKGROUND));

    a = 42; b = 0.5;
    for(int i=0; i<8; i++){
        if(i%2 == 0)
            Coins.push_back(Ball(a + i, b + 0.5, 0.2, COLOR_YELLOW));
        else
            Coins.push_back(Ball(a + i, b - 0.5, 0.2, COLOR_YELLOW));

    }


    magnets.push_back(Magnet(50, 1, 2, COLOR_YELLOW));
    magnets.push_back(Magnet(50, 1, 1, COLOR_BACKGROUND));

    // Create and compile our GLSL program from the shaders
    programID = LoadShaders("Sample_GL.vert", "Sample_GL.frag");
    // Get a handle for our "MVP" uniform
    Matrices.MatrixID = glGetUniformLocation(programID, "MVP");

    reshapeWindow(window, width, height);

    // Background color of the scene
    glClearColor(COLOR_BACKGROUND.r / 256.0, COLOR_BACKGROUND.g / 256.0, COLOR_BACKGROUND.b / 256.0, 0.0f); // R, G, B, A
    glClearDepth(1.0f);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);

    cout << "VENDOR: " << glGetString(GL_VENDOR) << endl;
    cout << "RENDERER: " << glGetString(GL_RENDERER) << endl;
    cout << "VERSION: " << glGetString(GL_VERSION) << endl;
    cout << "GLSL: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl;
}

int main(int argc, char **argv)
{
    srand(time(0));
    int width = 600;
    int height = 600;

    window = initGLFW(width, height);

    initGL(window, width, height);

    sprintf(title, "JetPackJoyride::Score : %d     Health : %d", score, health);

    /* Draw in loop */
    while (!glfwWindowShouldClose(window))
    {
        // Process timers

        if (t60.processTick())
        {
            // 60 fps
            // OpenGL Draw commands
            draw();
            // Swap Frame Buffer in double buffering
            glfwSwapBuffers(window);

            tick_elements();
            tick_input(window);
        }

        // Poll for Keyboard and mouse events
        glfwPollEvents();
    }

    quit(window);
}

bool detect_collision(bounding_box_t a, bounding_box_t b)
{
    return (abs(a.x - b.x) * 2 < (a.width + b.width)) &&
           (abs(a.y - b.y) * 2 < (a.height + b.height));
}

bool check_collision(bounding_box_t a, bounding_box_t b)
{
    if( abs(a.x - b.x) * abs(a.x - b.x) + abs(a.y - b.y) * abs(a.y - b.y) < (a.width + b.width) * (a.width + b.width))
    {
        return true;
    }   
    else
        return false;
}

bool check2_collision(bounding_box_t a, bounding_box_t b)
{
    if((a.x > b.x - b.width) && (a.x < b.x + b.width)){
        if(abs(a.y - b.y) <= a.height + b.height){
            return true;
        }
        else{
            return false;
        }
    }
    else{
        return false;
    }
}

bool check3_collision(bounding_box_t a, bounding_box_t b)
{
    if((a.y > b.y - b.height) && (a.y < b.y + b.height)){
        if(abs(a.x - b.x) <= a.width + b.width){
            return true;
        }
        else{
            return false;
        }
    }
    else{
        return false;
    }
}

bool check4_collision(bounding_box_t a, bounding_box_t b){
    if(a.x + a.width > b.x - b.width && a.x - a.width < b.x + b.width){
        if(a.y + a.height > b.y - b.width && a.y - a.height < b.y + b.width){
            return true;
        }
        else{
            return false;
        }
    }
    else{
        return false;
    }
}

void reset_screen()
{
    float top = screen_center_y + 4 / screen_zoom;
    float bottom = screen_center_y - 4 / screen_zoom;
    float left = screen_center_x - 4 / screen_zoom;
    float right = screen_center_x + 4 / screen_zoom;
    Matrices.projection = glm::ortho(left, right, bottom, top, 0.1f, 500.0f);
}
