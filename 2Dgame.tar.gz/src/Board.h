#include "main.h"

#ifndef BOARD_H
#define BOARD_H

class Board
{
  public:
    Board() {}
    Board(float x, float y,float height,float width, color_t color);
    glm::vec3 position;
    float width,height;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y);
    // void tick();
    // void collide();
    // double speed;
    // bounding_box_t coords();

  private:
    VAO *object;
};

#endif // BOARD_H
