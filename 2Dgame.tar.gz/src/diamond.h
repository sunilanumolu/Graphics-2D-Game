#include "main.h"

#ifndef DIAMOND_H
#define DIAMOND_H

class Diamond
{
  public:
    Diamond() {}
    Diamond(float x, float y, color_t color);
    glm::vec3 position;
    float rotation;
    int visible;
    void draw(glm::mat4 VP);
    void set_position(float x, float y);
    // void tick();
    // void collide();
    // double speed;
    //bounding_box_t coords();

  private:
    VAO *object;
};

#endif //DIAMOND_H